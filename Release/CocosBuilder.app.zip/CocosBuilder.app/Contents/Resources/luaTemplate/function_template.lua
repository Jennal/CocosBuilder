function __CLASS_NAME__:__FUNC_NAME__(sender, event)
    -- @TODO: implement this
end